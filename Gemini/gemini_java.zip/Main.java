import java.util.Scanner;

/**
 * Simple demo showing how to use the Gemini class
 * Replace YOUR_API_KEY_HERE with your actual API key from Google AI Studio
 */
public class Main {
    
    private static final String API_KEY = "YOUR_API_KEY_HERE";

    // Available Gemini models
    private static final String[] AVAILABLE_MODELS = {
        "gemini-1.5-flash",                // Fast and versatile (default)
        "gemini-1.5-pro",                  // Complex reasoning tasks
        "gemini-2.0-flash",                // Newest multimodal, fastest
        "gemini-2.0-flash-lite",           // Most cost-efficient
        "gemini-2.5-flash-preview-05-20",  // Best price-performance with thinking
        "gemini-2.5-pro-preview-05-06"     // Most powerful thinking model
    };
    
    private static final String[] MODEL_DESCRIPTIONS = {
        "Fast and versatile (recommended for beginners)",
        "Complex reasoning tasks (more powerful)",
        "Newest multimodal, fastest",
        "Most cost-efficient",
        "Best price-performance with thinking capabilities",
        "Most powerful thinking model (advanced reasoning)"
    };
    
    public static void main(String[] args) {
        System.out.println("==================================================");
        
        // Check that the key was replaced
        if (API_KEY.equals("YOUR_API_KEY_HERE")) {
            System.err.println("❌ Error: Please replace API_KEY in the code!");
            return;
        }
        
        try {
            Scanner scanner = new Scanner(System.in);
            
            // Show available models and let user choose
            String selectedModel = selectModel(scanner);
            
            // Create Gemini client with selected model
            Gemini gemini = new Gemini(API_KEY, selectedModel);
            
            System.out.println("🤖 Using model: " + gemini.getModelName());
            System.out.println("✅ Gemini is ready!");
            System.out.println("==================================================");
            
            System.out.print("🤔 Question: ");
            String question = scanner.nextLine();
            
            System.out.println("\n🤖 Gemini's Response:");
            System.out.println("------------------------------");
            
            // Ask Gemini - simple as that!
            String response = gemini.ask(question);
            System.out.println(response);
            System.out.println("\n==================================================");
            
            scanner.close();
            
        } catch (Exception e) {
            System.err.println("❌ Error occurred: " + e.getMessage());
            System.err.println("💡 Make sure the API key is correct and you have internet connection");
        }
    }
    
    /**
     * Display available models and let user select one
     */
    private static String selectModel(Scanner scanner) {
        System.out.println("📋 Available Gemini Models:");
        System.out.println("==================================================");
        
        for (int i = 0; i < AVAILABLE_MODELS.length; i++) {
            System.out.printf("%d. %s\n   %s\n\n", 
                i + 1, 
                AVAILABLE_MODELS[i], 
                MODEL_DESCRIPTIONS[i]);
        }
        
        System.out.print("🔢 Select model (1-" + AVAILABLE_MODELS.length + ") or press Enter for default [1]: ");
        String input = scanner.nextLine().trim();
        
        // Default to first model if no input
        if (input.isEmpty()) {
            System.out.println("✅ Using default model: " + AVAILABLE_MODELS[0]);
            return AVAILABLE_MODELS[0];
        }
        
        try {
            int choice = Integer.parseInt(input);
            if (choice >= 1 && choice <= AVAILABLE_MODELS.length) {
                System.out.println("✅ Selected model: " + AVAILABLE_MODELS[choice - 1]);
                return AVAILABLE_MODELS[choice - 1];
            } else {
                System.out.println("⚠️ Invalid choice. Using default model: " + AVAILABLE_MODELS[0]);
                return AVAILABLE_MODELS[0];
            }
        } catch (NumberFormatException e) {
            System.out.println("⚠️ Invalid input. Using default model: " + AVAILABLE_MODELS[0]);
            return AVAILABLE_MODELS[0];
        }
    }
} 