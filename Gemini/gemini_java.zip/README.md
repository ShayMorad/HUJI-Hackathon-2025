# Gemini Java Demo - Clean API Version
## Simple Gemini API with Black Box Design

### ⚡ What is this?
A clean, easy-to-use Gemini API for Java with no external dependencies!
- **`Gemini.java`** - The API (use as black box)
- **`Main.java`** - Simple demo
- **`Examples.java`** - Advanced usage examples

---

## 🚀 Quick Start (3 steps)

### Step 1: Get API Key

### Step 2: Edit the code
Open `Main.java` and replace:
```java
private static final String API_KEY = "YOUR_API_KEY_HERE";
```

### Step 3: Run
```bash
javac *.java
java Main
```

**That's it! It works!** 🎉

---

## 📁 What's in the folder?

```
java/
├── Gemini.java     ← The API (black box - don't touch!)
├── Main.java       ← Simple demo (edit this)
├── Examples.java   ← Advanced examples
└── README.md       ← This guide
```

---

## 🔧 Minimal Requirements

- **Java 8+** (any version since 2014)
- **Internet connection**
- **API key from Google AI Studio**

**That's all!** No Maven, Gradle, or external libraries needed.

---

## 💡 How to use as Black Box?

### Simple usage:
```java
// Create client
Gemini gemini = new Gemini("your-api-key");

// Ask question
String response = gemini.ask("What is AI?");
System.out.println(response);
```

### Advanced usage:
```java
// Custom model
Gemini gemini = new Gemini("your-api-key", "gemini-1.5-pro");

// Custom settings (creativity, length)
String response = gemini.ask("Write a poem", 0.9, 200);
```

### Available methods:
- `ask(question)` - Simple question
- `ask(question, temperature, maxTokens)` - With settings
- `getModelName()` - Get current model
- `isValidApiKeyFormat()` - Check API key format

---

## 🆘 Troubleshooting

### "YOUR_API_KEY_HERE"
❌ **Problem:** Forgot to replace the key  
✅ **Solution:** Go to step 2 above

### "API Error (403)"
❌ **Problem:** Wrong API key  
✅ **Solution:** Check you copied correctly from Google AI Studio

### "No response found"
❌ **Problem:** Internet connection issue  
✅ **Solution:** Check internet connection

### "javac: command not found"
❌ **Problem:** Java not installed  
✅ **Solution:** Install Java:
- **Windows:** Download from [Oracle](https://www.oracle.com/java/technologies/downloads/)
- **Mac:** `brew install openjdk`
- **Linux:** `sudo apt install openjdk-11-jdk`

---

## 🔄 Want to change something?

### Change model:
```java
Gemini gemini = new Gemini(apiKey, "gemini-1.5-pro"); // Stronger model
```

### Change settings:
```java
gemini.ask(question, 0.7, 1024); // creativity, max length
```

### Multiple questions:
```java
Gemini gemini = new Gemini(apiKey);
String answer1 = gemini.ask("First question");
String answer2 = gemini.ask("Second question");
```

---

## 🔧 For Advanced Users - Black Box API

The `Gemini.java` file is designed as a black box:
- **Clean interface** - Just create and call `ask()`
- **Error handling** - Proper exceptions and validation
- **JSON parsing** - Handles complex responses automatically
- **Fallback** - If parsing fails, uses simple method
- **Extensible** - Easy to add new features

### Example integration:
```java
public class MyApp {
    private Gemini ai;
    
    public MyApp(String apiKey) {
        this.ai = new Gemini(apiKey);
    }
    
    public String getAIResponse(String userInput) {
        try {
            return ai.ask(userInput);
        } catch (Exception e) {
            return "Sorry, AI is not available right now.";
        }
    }
}
```

---

## 🎉 That's it!

**Good luck! 🚀** 