import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Simple Gemini API client - use as a black box
 * Just create an instance with your API key and call ask()
 */
public class Gemini {
    
    private final String apiKey;
    private final String modelName;
    
    /**
     * Create a Gemini client with default model (gemini-1.5-flash)
     */
    public Gemini(String apiKey) {
        this(apiKey, "gemini-1.5-flash");
    }
    
    /**
     * Create a Gemini client with specific model
     */
    public Gemini(String apiKey, String modelName) {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalArgumentException("API key cannot be null or empty");
        }
        this.apiKey = apiKey.trim();
        this.modelName = modelName;
    }
    
    /**
     * Ask Gemini a question and get a response
     * @param question The question to ask
     * @return Gemini's response as a string
     * @throws Exception if there's an error communicating with the API
     */
    public String ask(String question) throws Exception {
        return ask(question, 0.7, 1024);
    }
    
    /**
     * Ask Gemini a question with custom settings
     * @param question The question to ask
     * @param temperature Creativity level (0.0-1.0)
     * @param maxTokens Maximum response length
     * @return Gemini's response as a string
     * @throws Exception if there's an error communicating with the API
     */
    public String ask(String question, double temperature, int maxTokens) throws Exception {
        if (question == null || question.trim().isEmpty()) {
            throw new IllegalArgumentException("Question cannot be null or empty");
        }
        
        // Validate input size to prevent memory issues
        if (question.length() > 100000) { // 100KB limit
            throw new IllegalArgumentException("Question too long (max 100,000 characters)");
        }
        
        // Validate parameters
        if (temperature < 0.0 || temperature > 1.0) {
            throw new IllegalArgumentException("Temperature must be between 0.0 and 1.0");
        }
        if (maxTokens < 1 || maxTokens > 8192) {
            throw new IllegalArgumentException("Max tokens must be between 1 and 8192");
        }
        
        String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + 
                         modelName + ":generateContent?key=" + apiKey;
        
        URL url = new URL(endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
        // Setup request with timeouts for production robustness
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setDoOutput(true);
        connection.setConnectTimeout(30000); // 30 seconds connect timeout
        connection.setReadTimeout(60000);    // 60 seconds read timeout
        
        // Create request body
        String requestBody = "{\n" +
                "  \"contents\": [{\n" +
                "    \"parts\": [{\n" +
                "      \"text\": \"" + escapeJson(question.trim()) + "\"\n" +
                "    }]\n" +
                "  }],\n" +
                "  \"generationConfig\": {\n" +
                "    \"temperature\": " + temperature + ",\n" +
                "    \"maxOutputTokens\": " + maxTokens + ",\n" +
                "    \"responseMimeType\": \"text/plain\"\n" +
                "  }\n" +
                "}";
        
        // Send request
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = requestBody.getBytes("utf-8");
            os.write(input, 0, input.length);
        }
        
        // Read response with size limit to prevent memory issues
        int responseCode = connection.getResponseCode();
        if (responseCode == 200) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine;
                int totalLength = 0;
                final int MAX_RESPONSE_SIZE = 1000000; // 1MB limit
                
                while ((responseLine = br.readLine()) != null) {
                    totalLength += responseLine.length();
                    if (totalLength > MAX_RESPONSE_SIZE) {
                        throw new Exception("Response too large (exceeds 1MB limit)");
                    }
                    response.append(responseLine.trim());
                }
                
                // Extract text from response
                return extractTextFromResponse(response.toString());
            }
        } else {
            // Read error
            try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getErrorStream(), "utf-8"))) {
                StringBuilder error = new StringBuilder();
                String errorLine;
                while ((errorLine = br.readLine()) != null) {
                    error.append(errorLine.trim());
                }
                throw new Exception("API Error (" + responseCode + "): " + error.toString());
            }
        }
    }
    
    /**
     * Get the current model name
     */
    public String getModelName() {
        return modelName;
    }
    
    /**
     * Check if the API key is valid format (starts with AIza)
     */
    public boolean isValidApiKeyFormat() {
        return apiKey.startsWith("AIza") && apiKey.length() > 20;
    }
    
    // ========== PRIVATE HELPER METHODS ==========
    
    /**
     * Extract text from API response using simple JSON parsing
     */
    private String extractTextFromResponse(String jsonResponse) {
        try {
            // Parse JSON to find the first "text" field in candidates
            JsonObject root = parseJson(jsonResponse);
            JsonArray candidates = root.getArray("candidates");
            if (candidates != null && candidates.size() > 0) {
                JsonObject firstCandidate = candidates.getObject(0);
                JsonObject content = firstCandidate.getObject("content");
                if (content != null) {
                    JsonArray parts = content.getArray("parts");
                    if (parts != null && parts.size() > 0) {
                        JsonObject firstPart = parts.getObject(0);
                        String text = firstPart.getString("text");
                        if (text != null) {
                            // Clean Unicode escape sequences
                            return cleanUnicodeEscapes(text);
                        }
                    }
                }
            }
            return "No response found in JSON structure";
        } catch (Exception e) {
            // Fallback to simple parsing if JSON parsing fails
            return cleanUnicodeEscapes(extractTextSimple(jsonResponse));
        }
    }
    
    /**
     * Fallback simple text extraction
     */
    private String extractTextSimple(String jsonResponse) {
        String textKey = "\"text\":";
        int startIndex = jsonResponse.indexOf(textKey);
        if (startIndex == -1) {
            return "No response found";
        }
        
        startIndex += textKey.length();
        while (startIndex < jsonResponse.length() && 
               (jsonResponse.charAt(startIndex) == ' ' || jsonResponse.charAt(startIndex) == '"')) {
            startIndex++;
        }
        
        int endIndex = startIndex;
        while (endIndex < jsonResponse.length()) {
            char c = jsonResponse.charAt(endIndex);
            if (c == '"' && (endIndex == 0 || jsonResponse.charAt(endIndex - 1) != '\\')) {
                break;
            }
            endIndex++;
        }
        
        String result = jsonResponse.substring(startIndex, endIndex);
        return unescapeJson(result);
    }
    
    /**
     * Prepare text for JSON (escape characters)
     */
    private String escapeJson(String text) {
        return text.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
    
        /**
     * Unescape JSON string
     */
    private String unescapeJson(String text) {
        return text.replace("\\n", "\n")
                  .replace("\\\"", "\"")
                  .replace("\\\\", "\\")
                  .replace("\\t", "\t")
                  .replace("\\r", "\r");
    }
    
    /**
     * Clean Unicode escape sequences from text (hidden from students)
     */
    private String cleanUnicodeEscapes(String text) {
        if (text == null) {
            return text;
        }
        
        // Use StringBuilder for better performance with large texts
        StringBuilder result = new StringBuilder(text.length());
        int i = 0;
        
        while (i < text.length()) {
            if (i < text.length() - 5 && text.charAt(i) == '\\' && text.charAt(i + 1) == 'u') {
                // Found a Unicode escape sequence
                try {
                    String hexCode = text.substring(i + 2, i + 6);
                    int codePoint = Integer.parseInt(hexCode, 16);
                    result.append((char) codePoint);
                    i += 6; // Skip the entire \\uXXXX sequence
                } catch (NumberFormatException e) {
                    // If parsing fails, just append the original characters
                    result.append(text.charAt(i));
                    i++;
                }
            } else {
                result.append(text.charAt(i));
                i++;
            }
        }
        
        return result.toString();
    }

 
    
    /**
     * Simple JSON parser - parses JSON string into JsonObject
     */
    private JsonObject parseJson(String json) {
        json = json.trim();
        if (!json.startsWith("{") || !json.endsWith("}")) {
            throw new RuntimeException("Invalid JSON object");
        }
        return new JsonObject(json);
    }
    
    // ========== INNER CLASSES FOR JSON PARSING ==========
    
    /**
     * Simple JSON Object implementation
     */
    static class JsonObject {
        private String json;
        
        public JsonObject(String json) {
            this.json = json;
        }
        
        public JsonArray getArray(String key) {
            String value = getValue(key);
            if (value != null && value.startsWith("[") && value.endsWith("]")) {
                return new JsonArray(value);
            }
            return null;
        }
        
        public JsonObject getObject(String key) {
            String value = getValue(key);
            if (value != null && value.startsWith("{") && value.endsWith("}")) {
                return new JsonObject(value);
            }
            return null;
        }
        
        public String getString(String key) {
            String value = getValue(key);
            if (value != null && value.startsWith("\"") && value.endsWith("\"")) {
                return value.substring(1, value.length() - 1)
                           .replace("\\n", "\n")
                           .replace("\\\"", "\"")
                           .replace("\\\\", "\\")
                           .replace("\\t", "\t")
                           .replace("\\r", "\r");
            }
            return null;
        }
        
        private String getValue(String key) {
            String searchKey = "\"" + key + "\":";
            int startIndex = json.indexOf(searchKey);
            if (startIndex == -1) return null;
            
            startIndex += searchKey.length();
            // Skip whitespace
            while (startIndex < json.length() && Character.isWhitespace(json.charAt(startIndex))) {
                startIndex++;
            }
            
            if (startIndex >= json.length()) return null;
            
            char firstChar = json.charAt(startIndex);
            int endIndex;
            
            if (firstChar == '"') {
                // String value
                endIndex = findStringEnd(json, startIndex);
            } else if (firstChar == '{') {
                // Object value
                endIndex = findObjectEnd(json, startIndex);
            } else if (firstChar == '[') {
                // Array value
                endIndex = findArrayEnd(json, startIndex);
            } else {
                // Primitive value (number, boolean, null)
                endIndex = findPrimitiveEnd(json, startIndex);
            }
            
            if (endIndex == -1) return null;
            return json.substring(startIndex, endIndex + 1);
        }
        
        private int findStringEnd(String json, int start) {
            int i = start + 1; // Skip opening quote
            while (i < json.length()) {
                char c = json.charAt(i);
                if (c == '"' && json.charAt(i - 1) != '\\') {
                    return i;
                }
                i++;
            }
            return -1;
        }
        
        private int findObjectEnd(String json, int start) {
            int braceCount = 0;
            for (int i = start; i < json.length(); i++) {
                char c = json.charAt(i);
                if (c == '{') braceCount++;
                else if (c == '}') braceCount--;
                if (braceCount == 0) return i;
            }
            return -1;
        }
        
        private int findArrayEnd(String json, int start) {
            int bracketCount = 0;
            for (int i = start; i < json.length(); i++) {
                char c = json.charAt(i);
                if (c == '[') bracketCount++;
                else if (c == ']') bracketCount--;
                if (bracketCount == 0) return i;
            }
            return -1;
        }
        
        private int findPrimitiveEnd(String json, int start) {
            for (int i = start; i < json.length(); i++) {
                char c = json.charAt(i);
                if (c == ',' || c == '}' || c == ']' || Character.isWhitespace(c)) {
                    return i - 1;
                }
            }
            return json.length() - 1;
        }
    }
    
    /**
     * Simple JSON Array implementation
     */
    static class JsonArray {
        private String json;
        
        public JsonArray(String json) {
            this.json = json;
        }
        
        public int size() {
            if (json.equals("[]")) return 0;
            
            int count = 0;
            int bracketCount = 0;
            int braceCount = 0;
            boolean inString = false;
            
            for (int i = 1; i < json.length() - 1; i++) {
                char c = json.charAt(i);
                
                if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) {
                    inString = !inString;
                } else if (!inString) {
                    if (c == '[') bracketCount++;
                    else if (c == ']') bracketCount--;
                    else if (c == '{') braceCount++;
                    else if (c == '}') braceCount--;
                    else if (c == ',' && bracketCount == 0 && braceCount == 0) {
                        count++;
                    }
                }
            }
            
            return count + 1; // +1 for the last element
        }
        
        public JsonObject getObject(int index) {
            String element = getElement(index);
            if (element != null && element.startsWith("{") && element.endsWith("}")) {
                return new JsonObject(element);
            }
            return null;
        }
        
        private String getElement(int index) {
            if (json.equals("[]")) return null;
            
            int currentIndex = 0;
            int start = 1; // Skip opening bracket
            int bracketCount = 0;
            int braceCount = 0;
            boolean inString = false;
            
            for (int i = 1; i < json.length() - 1; i++) {
                char c = json.charAt(i);
                
                if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) {
                    inString = !inString;
                } else if (!inString) {
                    if (c == '[') bracketCount++;
                    else if (c == ']') bracketCount--;
                    else if (c == '{') braceCount++;
                    else if (c == '}') braceCount--;
                    else if (c == ',' && bracketCount == 0 && braceCount == 0) {
                        if (currentIndex == index) {
                            return json.substring(start, i).trim();
                        }
                        currentIndex++;
                        start = i + 1;
                    }
                }
            }
            
            // Last element
            if (currentIndex == index) {
                return json.substring(start, json.length() - 1).trim();
            }
            
            return null;
        }
    }
} 