/**
 * Examples showing different ways to use the Gemini class
 * This demonstrates how easy it is to use Gemini as a black box
 */
public class Examples {
    
    private static final String API_KEY = "your_api_key";
    
    public static void main(String[] args) {
        try {
            // Example 1: Basic usage
            basicExample();
            
            // Example 2: Custom settings
            customSettingsExample();
            
            // Example 3: Different models
            differentModelsExample();
            
            // Example 4: Error handling
            errorHandlingExample();
            
        } catch (Exception e) {
            System.err.println("Error in examples: " + e.getMessage());
        }
    }
    
    /**
     * Example 1: Basic usage - just ask a question
     */
    public static void basicExample() throws Exception {
        System.out.println("=== Example 1: Basic Usage ===");
        
        Gemini gemini = new Gemini(API_KEY);
        String response = gemini.ask("What is artificial intelligence?");
        System.out.println("Response: " + response);
        System.out.println();
    }
    
    /**
     * Example 2: Custom settings - control creativity and length
     */
    public static void customSettingsExample() throws Exception {
        System.out.println("=== Example 2: Custom Settings ===");
        
        Gemini gemini = new Gemini(API_KEY);
        
        // More creative response (higher temperature)
        String creative = gemini.ask("Write a short poem about coding", 0.9, 200);
        System.out.println("Creative response: " + creative);
        
        // More factual response (lower temperature)
        String factual = gemini.ask("Explain what is Java programming", 0.1, 500);
        System.out.println("Factual response: " + factual);
        System.out.println();
    }
    
    /**
     * Example 3: Different models
     */
    public static void differentModelsExample() throws Exception {
        System.out.println("=== Example 3: Different Models ===");
        
        // Available models
        String[] models = {
            "gemini-1.5-flash",                // Fast and versatile
            "gemini-1.5-pro",                  // Complex reasoning
            "gemini-2.0-flash",                // Newest multimodal
            "gemini-2.0-flash-lite",           // Cost-efficient
            "gemini-2.5-flash-preview-05-20",  // Best price-performance
            "gemini-2.5-pro-preview-05-06"     // Most powerful
        };
        
        // Test with different models
        String question = "What is the capital of France?";
        
        for (String model : models) {
            try {
                Gemini gemini = new Gemini(API_KEY, model);
                System.out.println("Model: " + model);
                String response = gemini.ask(question);
                System.out.println("Response: " + response);
                System.out.println("---");
            } catch (Exception e) {
                System.out.println("Model " + model + " failed: " + e.getMessage());
                System.out.println("---");
            }
        }
        System.out.println();
    }
    
    /**
     * Example 4: Error handling
     */
    public static void errorHandlingExample() {
        System.out.println("=== Example 4: Error Handling ===");
        
        try {
            // This will throw an exception - invalid API key
            Gemini badGemini = new Gemini("");
        } catch (IllegalArgumentException e) {
            System.out.println("Caught expected error: " + e.getMessage());
        }
        
        try {
            Gemini gemini = new Gemini(API_KEY);
            
            // Check API key format
            if (gemini.isValidApiKeyFormat()) {
                System.out.println("API key format looks valid");
            } else {
                System.out.println("API key format might be invalid");
            }
            
            // This will work
            String response = gemini.ask("Hello!");
            System.out.println("Response: " + response);
            
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        System.out.println();
    }
} 